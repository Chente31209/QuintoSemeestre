function ver(){
    var numerico = 22;
    var NuemroFlotante=13.1;
    var Texto ="hola";
    var Date = new date();
    alert(`HolaMundo${Date}`);
    document.write("<br> el tipo es "+ typeof Date);
}
function  mifuncion(){
    document.write("esto ba bien")
}

function Hola(){
    alert("Hola")
}